g++ testjson.cpp libjsoncpp.a -I include
